from functions import *
import json
from flask_lambda import FlaskLambda
from flask import Flask, request, jsonify
# import requests

app = FlaskLambda(__name__)
@app.route('/query', methods=['GET', 'POST'])
def auto_generative():
  query = str(request.get_json()['query'])
  openai_api_key = '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'
  llm = OpenAI(temperature=0.0, openai_api_key=openai_api_key)
  auth = "eyJhbGciOiJIUzI1NiJ9.eyJ0ZW5hbnRVVUlEIjoiZjJjOTVmNzctMmVkZC00Mjk5LWI3ZmMtNDg5NjdhNDNiNTE2Iiwic3ViIjoiYWRtaW5AYXBwc3RlZXIuYWkiLCJyb2xlIjoiQ09SUE9SQVRFX0FETUlOIiwiaXNzIjoiQXBwU3RlZXIiLCJmdWxsTmFtZSI6IkFwcHN0ZWVyIEFJICIsIm9yZ0RvbWFpbk5hbWUiOiJhaS5hcHBzdGVlci5pbyIsInByZWZlcnJlZF91c2VybmFtZSI6ImFkbWluQGFwcHN0ZWVyLmFpIiwicm9sZVVVSUQiOiIzOWQwNjMwMC0xZjA3LTExZWUtOGVmZi0wMDIyNDgyNjk0ODAiLCJ1dWlkIjoiZDFkM2NkM2ItMWYwNy0xMWVlLThlZmYtMDAyMjQ4MjY5NDgwIiwidXNlcklkIjo3NDMsInVpZCI6ImI0MTlhMzc5LTE4NzYtNGNlZC05MDE3LTk4NGM5ZjVkOThiOSIsInRlbmFudElkIjo0MSwiZXhwIjoxNjkwNTEyMDI5LCJpYXQiOjE2OTA0MjU2Mjl9.6LZ0_GF-u3_78BURJ6uwAuButEwuAz9Ut8amp1sTUrM"

  data = data_prep_chain1(query)
  memory_chain(data, llm)
  output_ch1 = form_chain(data, llm)
  response_form = create_form(output_ch1, auth)
  form_id = json.loads(response_form.text)['data']['formId']
  output_fields = generate_page_data(output_ch1, llm)
  for data_slice in output_fields.split("\n  \n  "):
    data_output_ch2 = data_prep_chain2(data_slice)
    output_view_header_ch = view_header_chain(data_output_ch2, llm)
    response_view = create_view(output_view_header_ch, formId=form_id, auth=auth)
    view_id = json.loads(response_view.text)['data']
    response_header = create_header(output_view_header_ch, formViewId=view_id, auth=auth)
    header_id = json.loads(response_header.text)['data']
    output_ch3 = data_prep_chain3(data_slice)
    output_field_ch = field_chain(output_ch3, llm)
    create_fields(output_field_ch, headerId=header_id, auth=auth)

  return (json.dumps({'success':'application created'}), 200, {'Content-Type':'application/json'})

if __name__=="__main__":
  app.run(debug=True)