from transformers import AutoTokenizer, AutoModelWithLMHead
import json
from pathlib import Path
from pprint import pprint
from langchain.agents import load_tools
from langchain.agents import initialize_agent
from langchain.agents import AgentType
from langchain.llms import OpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.chains import SimpleSequentialChain

def data_prep_chain1(query):
  app_json = '''{
          "formName": "Import Test App",
          "versionNumber": 1,
          "typeId": 1,
          "formDescription": "Import Test App",
          "language": [
            {
              "id": 3,
              "language": "English (India)",
              "nativeText": "English",
              "renderingOrder": "Left to right",
              "iso": "en",
              "renderingCode": "LTR",
              "lcid": "en",
              "isActive": 0,
              "isCustom": 0,
              "flag": true,
              "default": true
            }
          ],
          "icon": "",
          "formViewName": "View",
          "headerName": "Header",
          "workspaceId": [1, 203]
        }
      '''

  app_json = json.loads(app_json)

  # query = user_input + ". " + prompt_input

  custom_keys = '''
  {
    "formName": "Name of the application as specified by the user. If user didn't specify a name, Generate and assign it a name based on the 'user_input'.",
    "typeId": "This is a static integer type, you can assign it a value of 1.",
    "formDescription": "In about 5 to 10 words, describe what the application is about. Keep it short and to the point.",
    "formViewName": "Name of the view as specified by the user. If user didn't specify a name, give it a random name.",
    "headerName": "Name of the header as specified by the user. If user didn't specify a name, give it a random name.",
    "user_input": ""
  }
  '''

  custom_keys_json = json.loads(custom_keys)
  custom_keys_json["user_input"] = query

  json_pop = {}
  json_pop['app_json'] = app_json
  json_pop['custom_keys_json'] = custom_keys_json

  return json_pop

def memory_chain(data, llm):
  template = """I am providing you with a JSON structure where you need to focus on the elements of the key 'custom_keys_json' the value of each key is a description of how to extract the actual value of the respective key.
  The structure also contains a key named 'user_input'.
  Your task is to return the keys (except the key named 'user_input') and the description of how each key can be extracted from a text. Also return the "user_input".

  % JSON STRUCTURE TO FOLLOW
  {app_json}

  YOUR RESPONSE:
  """

  prompt_template = PromptTemplate(input_variables=["app_json"], template=template)

  # Holds my 'location' chain
  location_chain = LLMChain(llm=llm, prompt=prompt_template)
  overall_chain = SimpleSequentialChain(chains=[location_chain], verbose=True)
  json_pop_str = str(data)
  review = overall_chain.run(json_pop_str)

def form_chain(json_pop, llm):
  template = """Your job is to extract the values of each key from the user_input key.
  Next, use 'app_json' JSON as a template and fill the value of keys.
  Next, assign the extracted value to each key.
  Finally return the created JSON structure.
  Note that the returned JSON must contain only the keys present in the 'app_json' elements.

  % USER INPUT
  {user_input}
  YOUR RESPONSE:
  """
  prompt_template = PromptTemplate(input_variables=["user_input"], template=template)

  instructions_chain = LLMChain(llm=llm, prompt=prompt_template)

  overall_chain = SimpleSequentialChain(chains=[instructions_chain], verbose=True)
  json_pop_str = str(json_pop)
  review = overall_chain.run(json_pop_str)

  return review


import requests


def create_form(review, auth):
    app = json.loads(review)
    app['language'] = str(app['language'])
    data = {'app': app}

    url = 'https://ai.sandbox.appsteer.io/services/web/form'

    form_data = {'app': json.dumps(data['app'])}

    headers = {"Authorization": "Bearer " + auth}

    print("creating form:", app)
    resp = requests.post(url=url, files=form_data, headers=headers)
    print(resp)
    print(resp.text)
    print('-' * 50)
    return resp

def generate_page_data(data, llm):
  app_name = json.loads(data)['formName']
  user_input = f"what all fields are required for a {app_name}"

  template = """Your task is to suggest 10-15 fields required for an application based on the user input provided.\
  Additionally, you need to assign relevant components from the given list to each suggested field. Please follow these instructions:
  1. Group the generated fields into different pages. Each group represents a page of the application and each page must have atmost 6 fields.
  2. Assign a header name to each page.
  3. Return the pages along with their header names and the fields included in them.
  Use the following list of components to assign to the fields:
  ["Text", "Numeric Text Box", "Label", "Multi select", "Dropdown List", "Radio Button", "Checkbox", "Separator", "Date Picker",
  "Variable", "Static Image", "Photo Validator", "Photograph", "Attachments", "Audio", "Video", "Signature"]

  % USER INPUT
  {user_input}
  YOUR RESPONSE:
  """

  prompt_template = PromptTemplate(input_variables=["user_input"], template=template)

  field_suggestion_chain = LLMChain(llm=llm, prompt=prompt_template)

  overall_chain = SimpleSequentialChain(chains=[field_suggestion_chain], verbose=True)
  review = overall_chain.run(user_input)

  return review

# Function creates data for LLM that would generate view and header JSON payloads.
def data_prep_chain2(prompt_input):
  view_json = '''{
  "commentRequired": 0,
  "formId": 797,
  "formViewName": "View 2",
  "generateNotifications": 0,
  "isMandatory": 1,
  "versionNumber": ""
  }
  '''

  view_json = json.loads(view_json)

  header_json = '''{
      "displayInView": 1,
      "formViewId": 1319,
      "headerAttributes": [],
      "headerName": "Header 1",
      "isMandatory": 1,
      "splitCount": 1,
      "versionNumber": ""
      }
      '''

  header_json = json.loads(header_json)

  json_pop = {}
  json_pop['view_json'] = view_json
  json_pop['header_json'] = header_json
  json_pop["user_input"] = prompt_input

  return json_pop

# Function for LLM that generates view and header JSON payloads.
def view_header_chain(json_pop, llm):
  template = """Your job is to go through the text provided in 'user_input'.
  Next, you need to create 2 JSON objects using 'header_json' and 'view_json' as templates.
  Next, in header_json template, assign the value of 'headerName' as the value of 'Header Name' key from 'user_input'.
  Next, in view_json template assign the value of 'formViewName' as a page name (eg. Page 1) based on the 'user_input'.
  Finally, return a single JSON object containing the 2 created JSON objects.

  % USER INPUT
  {user_input}
  YOUR RESPONSE:
  """
  prompt_template = PromptTemplate(input_variables=["user_input"], template=template)

  field_chain = LLMChain(llm=llm, prompt=prompt_template)
  overall_chain = SimpleSequentialChain(chains=[field_chain], verbose=True)
  json_pop_str = str(json_pop)
  review = overall_chain.run(json_pop_str)

  return review

# Function POSTs view and header JSON payloads API.
def create_view(input, formId, auth):

  input = json.loads(input)
  view_json = input['view_json']
  view_json['formId'] = formId
  view_attributes = [{"attributeId":1,"attributeName":"Orientation","defaultAttributeValues":"[{\\\"id\\\":1,\\\"value\\\":\\\"Landscape\\\"},{\\\"id\\\":0,\\\"value\\\":\\\"Portrait\\\"}]","attributeValues":"{\\\"id\\\":0,\\\"value\\\":\\\"Portrait\\\"}","valueType":"JSON"},{"attributeId":2,"attributeName":"Orientation Lock","defaultAttributeValues":"false","attributeValues":"false","valueType":"Boolean"},{"attributeId":3,"attributeName":"Show Welcome Message","defaultAttributeValues":"false","attributeValues":"false","valueType":"Boolean"},{"attributeId":4,"attributeName":"Welcome Message","defaultAttributeValues":"<html><body><center><div><p style='color:#146a93; font-size:125%; font-family:roboto, sans-serif'>Select <B>Continue</B> to capture data<BR />or<BR /><B>Skip</B> if you don't want to capture data for this form</p></div></center></body></html>","attributeValues":"<html><body><center><div><p style='color:#146a93; font-size:125%; font-family:roboto, sans-serif'>Select <B>Continue</B> to capture data<BR />or<BR /><B>Skip</B> if you don't want to capture data for this form</p></div></center></body></html>","valueType":"String"},{"attributeId":5,"attributeName":"Capture Geo Location","defaultAttributeValues":"false","attributeValues":"false","valueType":"Boolean"},{"attributeId":6,"attributeName":"Time gap between two views(In Mins)","defaultAttributeValues":"0","attributeValues":"0","valueType":"Integer"},{"attributeId":7,"attributeName":"Show notification when view enabled","defaultAttributeValues":"false","attributeValues":"false","valueType":"Boolean"},{"attributeId":8,"attributeName":"Show Full Screen","defaultAttributeValues":"false","attributeValues":"false","valueType":"Boolean"},{"attributeId":9,"attributeName":"IS PII","defaultAttributeValues":"false","attributeValues":"false","valueType":"Boolean"},{"attributeId":10,"attributeName":"Restrict User/Group","defaultAttributeValues":"[]","attributeValues":"[]","valueType":"JSON"},{"attributeId":11,"attributeName":"IsDefault ","defaultAttributeValues":"false","attributeValues":"false","valueType":"Boolean"},{"attributeId":12,"attributeName":"Show Headers","defaultAttributeValues":"true","attributeValues":"true","valueType":"Boolean"}]
  view_json['viewAttribute'] = view_attributes

  url = 'https://ai.sandbox.appsteer.io/services/web/formView/CreateFormView'

  headers = {"Authorization": "Bearer "+auth}
  # post view
  print('posting view')
  print('view')
  # pprint(view_json)
  resp = requests.post(url=url, json=view_json, headers=headers)
  print(resp.text)
  print('-'*30)
  return resp

# Function POSTs view and header JSON payloads API.
def create_header(input, formViewId, auth):

  input = json.loads(input)
  header_json = input['header_json']
  header_json['formViewId'] = formViewId
  header_attributes = [{"headerId":0,"attributeId":1,"attributeName":"Restrict User/Group","defaultAttributeValues":"[]","attributeValues":"[]","valueType":"JSON","propertyBoxBehaviour":0},{"headerId":0,"attributeId":2,"attributeName":"Column Layout","defaultAttributeValues":"[{\\\"id\\\":0,\\\"value\\\":\\\"Responsive\\\"}]","attributeValues":"[{\\\"id\\\":0,\\\"value\\\":\\\"Responsive\\\"}]","valueType":"JSON","propertyBoxBehaviour":0},{"headerId":0,"attributeId":3,"attributeName":"Responsive","defaultAttributeValues":"[]","attributeValues":"[]","valueType":"JSON","propertyBoxBehaviour":0},{"headerId":0,"attributeId":4,"attributeName":"IsDefault ","defaultAttributeValues":"false","attributeValues":"false","valueType":"Boolean","propertyBoxBehaviour":0}]
  header_json['headerAttributes'] = header_attributes

  url = 'https://ai.sandbox.appsteer.io/services/web/header/CreateHeader'

  headers = {"Authorization": "Bearer "+auth}

  # post header
  print('posting header')
  print('header')
  # pprint(header_json)
  resp = requests.post(url=url, json=header_json, headers=headers)
  print(resp.text)
  print('-'*30)
  return resp

# Data preparation for creating fields JSON
def data_prep_chain3(prompt_input):
  fields_json = '''{
    "fieldAttributes": [{}],
    "headerId": 2575,
    "isMandatory": 1,
    "uiLabel": "Text",
    "uiType": 0,
    "validatorId": []
  }
  '''

  fields_json = json.loads(fields_json)

  field_ids = '''
      {
        "Text": 0,
        "Numeric Text Box": 18,
        "Label": 33,
        "Multi select": 31,
        "Dropdown List": 2,
        "Radio Button": 1,
        "Checkbox": 3,
        "Separator": 16,
        "Date Picker": 7,
        "variable": 38,
        "Static Image": 26,
        "Photo Validator": 23,
        "Photograph": 5,
        "Attachments": 21,
        "Audio": 8,
        "Video": 10,
        "Signature": 19
      }
  '''

  field_ids_json = json.loads(field_ids)
  field_ids_json['headerId'] = 2575

  json_pop = {}
  json_pop['fields_json'] = fields_json
  json_pop['field_ids_json'] = field_ids_json
  json_pop["user_input"] = prompt_input

  return json_pop

def field_chain(json_pop, llm):
  template = """Your job is to go through the text provided in 'user_input', and for the listings under 'Fields', map what all keys from 'field_ids_json' are required.
  Now, the listings under 'Fields' in 'user_input' are in such a way, that the left part corresponds to the 'uiLabel' and the right part corresponds to the type of field (to be mapped).
  Next, for each of the required components, create a JSON structure with all the keys present in the 'fields_json'.
    Now in the created 'fields_json' object:
    1. assign the value of 'uiLabel' based on the extracted uiLabel from listings under Fields.
    2. assign the value of 'uiType' as an integer type based on the mapping provided in field_ids_json.

  Finally, concatenate the json objects of all the required components and return it
  Note that the returned JSONs must contain only the keys ['uiLabel', 'uiType']!

  % USER INPUT
  {user_input}
  YOUR RESPONSE:
  """
  prompt_template = PromptTemplate(input_variables=["user_input"], template=template)

  # Holds my 'location' chain
  field_chain = LLMChain(llm=llm, prompt=prompt_template)
  overall_chain = SimpleSequentialChain(chains=[field_chain], verbose=True)
  json_pop_str = str(json_pop)
  review = overall_chain.run(json_pop_str)

  return review

def create_fields(output_ch3, headerId, auth):

  field_template = '''{\
  "fieldAttributes": [{}],\
  "headerId": 123,\
  "isMandatory": 1,\
  "uiLabel": "Text",\
  "uiType": 0,\
  "validatorId": []\
  }\
  '''

  field_template = json.loads(field_template)
  field_template['headerId'] = headerId

  fields = json.loads(output_ch3)
  for field in fields:
    field_template['uiLabel'] = field['uiLabel']
    field_template['uiType'] = field['uiType']

    print('creating:', field_template)

    url = 'https://ai.sandbox.appsteer.io/services/web/formField/CreateFormField'

    headers = {"Authorization": "Bearer "+auth}

    resp = requests.post(url=url, json=field_template, headers=headers)
    print(resp.text)
    print('-'*30)

